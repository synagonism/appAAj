# appAAj

this is the-last version 00-02-02.2010-06-20 of my AAj-app with minor updates to work today {2023-09-16}.

AAj is a-java-app that manages [senso-concepts-Mcs](https://synagonism.net/dirMcs/dirCor/McsCor000002.last.html#idOverview) written in Xml.

unfortunately, all commands of the app do not work today.
it contains and the-documentation written for my HtmlMgr-app.

you can download the-whole project by downloading the dirAAj.zip file, unzip it and work with the-app by running the aaaRunAAj.bat file in win or the-command "java pk_XKBManager.AAj hknu.symb-7" inside the-AAjProgram directory.

https://synagonism.net/dirMcs/dirCor/McsCor000002.last.html#idMcsmAaj